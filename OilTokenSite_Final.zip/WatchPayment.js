// WatchPayment.js
const ownerWallet = "UQCQ0A_nGICwBavJs9FbGclF7NYAv_cEkScvpU1XeppmyEqZ";
let oilPriceTON = 0.01;
function calculatePayment() {
    const tokenAmount = parseFloat(document.getElementById("tokenAmount").value);
    if (isNaN(tokenAmount) || tokenAmount <= 0) {
        alert("Please enter a valid token amount");
        return;
    }
    const totalTON = tokenAmount * oilPriceTON;
    document.getElementById("totalTON").innerText = totalTON.toFixed(4) + " TON";
}
function showWithdrawalInfo() {
    const tokenAmount = parseFloat(document.getElementById("tokenAmount").value);
    if (isNaN(tokenAmount) || tokenAmount <= 0) {
        alert("Please enter a valid token amount");
        return;
    }
    const totalTON = tokenAmount * oilPriceTON;
    document.getElementById("withdrawalInfo").innerHTML =
        `<p>Payment Amount: <b>${totalTON.toFixed(4)} TON</b></p>
         <p>Owner Wallet Address: <b>${ownerWallet}</b></p>`;
}
function updatePrice(newPrice) {
    oilPriceTON = parseFloat(newPrice);
    document.getElementById("currentPrice").innerText = oilPriceTON + " TON / OIL";
}